// Navbar Style
var MyDivar = document.querySelector(".MyDivar");
MyDivar.addEventListener("click",()=>{
    let MyDivar__menu = document.querySelector(".MyDivar__Drop--Drown");
    let MyDivar__menu__Class = MyDivar__menu.classList;
    MyDivar__menu__Class.toggle("d-block");
});


var Advertisement__modal = document.querySelector(".Advertisement");
var Advertising__btn = document.querySelector(".Advertising");
var Advertisement__Moddal__CloseBtn = document.querySelector(".Advertisement-Moddal__header--CloseBtn");
Advertising__btn.addEventListener("click",()=>{
    Advertisement__modal.classList.add("visible");
    body.style.overflow = "none !important";
});
Advertisement__Moddal__CloseBtn.addEventListener("click",()=>{
    Advertisement__modal.classList.remove("visible");
});

// Sidebar Style
var Aside__items__Rarrow = document.querySelectorAll(".Side-bar__items--arrow-right");
var Aside__items__Larrow = document.querySelectorAll(".Side-bar__items--arrow-left");
var Aside__items = document.querySelectorAll(".Side-bar__items");
var Side_bar__items__lable = document.querySelectorAll(".Side-bar__items--lable");

// var Aside__location__SelectCity = document.querySelector(".Aside__location--SelectCity");
for (let i = 0; i < Aside__items.length; i++) {
    Side_bar__items__lable[i].addEventListener("click",()=>{
        Aside__items__Rarrow[i].classList.toggle("rotate135");
        Aside__items__Larrow[i].classList.toggle("rotate-135");
        Aside__items[i].classList.toggle("h-none");
        Aside__items[i].classList.toggle("pb-1");
    });
}
